#include "stdafx.h"

//#define SHOWDIALOGFUNCTION_EXPORT

//#include "DialogShowQuery.h"

void g_DlgQueryGeometriesFromDB ( )
{
	//DialogShowQuery dialog;
	//dialog.DoModal ( );
	return;
}