#pragma once
#ifndef _SHOWDIALOGFUNCTION_H_
#define _SHOWDIALOGFUNCTION_H_


void g_DlgQueryGeometriesFromDB ( );

#endif