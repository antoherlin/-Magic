#pragma once
#include "BaseTool.h"
#include "stdafx.h"
#include "Magic_Struct.h"
#include "MagicGis_UpdateDoc.h"
class CMagicGis_Area:public CBaseTool
{
public:
	CMagicGis_Area(void);
	CMagicGis_Area(CView* ptView);
	~CMagicGis_Area(void);
public:
	void Draw(GeoCircle &Area, CDC *pDC);
	void SelectArea(CPoint &point, CDC *pDC);
	void ModifyArea(CPoint &point, CDC *pDC);
	void MoveArea(CPoint &point, CDC *pDC);
	void DeleteArea(CPoint &point, CDC *pDC);
	void SquareDeleteArea(CDC *pDC);
	void DrawBuffer(GeoCircle &circle,CDC *pDC,int r,COLORREF color);
	int LButtonDown(CDC *pDC, UINT nFlags, CPoint point);
	int MouseMove(CDC *pDC, UINT nFlags, CPoint point);
	int RButtonUp(CDC *pDC, UINT nFlags, CPoint point);
	int LButtonUp(CDC *pDC, UINT nFlags, CPoint point);
private:
	long	m_step;
	POINT	m_startPnt;
	POINT	m_lastPnt;
	GeoCircle Area;
	CBrush *pOldBrush;
	CPen *pOldPen;
public:
	void DrawBuffer(CDC * pDC, SeqStack<GeoCircle> & s_circle, int radium, CMagicGis_UpdateDoc * pDoc);
};

