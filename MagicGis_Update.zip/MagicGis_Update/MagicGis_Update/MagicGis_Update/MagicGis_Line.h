#pragma once
#include "BaseTool.h"
#include "Magic_Struct.h"
#include "MagicGis_UpdateDoc.h"
class CMagicGis_Line :public CBaseTool
{
public:
	CMagicGis_Line(void);
	CMagicGis_Line(CView* ptView);
	virtual~CMagicGis_Line(void);
public:
	void Draw(GeoLine &line, CDC *pDC);
	void Select(CPoint &point, CDC *pDC);
	void Modify(CPoint &point, CDC *pDC);
	void Move(CPoint &point, CDC *pDC);
	void Delete(CPoint &point, CDC *pDC);
	void SquareDelete(CDC *pDC);
	void Cut(CPoint &point, CDC *pDC);
	int LButtonDown(CDC *pDC, UINT nFlags, CPoint point);
	int LButtonUp(CDC *pDC, UINT nFlags, CPoint point);
	int MouseMove(CDC *pDC, UINT nFlags, CPoint point);
	int RButtonUp(CDC *pDC, UINT nFlags, CPoint point);
private:
	GeoLine line;
	short	m_step;
	CPoint	m_lastStart;
	CPoint	m_lastEnd;
	CPen *pOldPen;

public:
	void DrawBuffer(CDC * pDC, SeqStack<GeoLine> & m_Line, int radium, CMagicGis_UpdateDoc *pDoc);
};
