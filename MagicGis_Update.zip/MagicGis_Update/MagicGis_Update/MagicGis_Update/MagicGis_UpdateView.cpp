
// MagicGis_UpdateView.cpp : CMagicGis_UpdateView ���ʵ��
//
#pragma once
#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "MagicGis_Update.h"
#endif

#include "MagicGis_UpdateDoc.h"
#include "MagicGis_UpdateView.h"
#include "Resource.h"
#include "SetBuffer.h"
#include "Handlefunction.h"

#include "My-DataManager.h"
#include "DialogShowQuery.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMagicGis_UpdateView

IMPLEMENT_DYNCREATE(CMagicGis_UpdateView, CView)

BEGIN_MESSAGE_MAP(CMagicGis_UpdateView, CView)
	// ��׼��ӡ����
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMagicGis_UpdateView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_AddPoint, &CMagicGis_UpdateView::OnAddpoint)
	ON_COMMAND(ID_ModifyPoint, &CMagicGis_UpdateView::OnModifypoint)
	ON_COMMAND(ID_DeletePoint, &CMagicGis_UpdateView::OnDeletepoint)
	ON_COMMAND(ID_AddLine, &CMagicGis_UpdateView::OnAddline)
	ON_COMMAND(ID_ModifyLine, &CMagicGis_UpdateView::OnModifyline)
	ON_COMMAND(ID_DeleteLine, &CMagicGis_UpdateView::OnDeleteline)
	ON_COMMAND(ID_AddArea, &CMagicGis_UpdateView::OnAddarea)
	ON_COMMAND(ID_ModifyArea, &CMagicGis_UpdateView::OnModifyarea)
	ON_COMMAND(ID_DeleteArea, &CMagicGis_UpdateView::OnDeletearea)
	ON_COMMAND(ID_Buffer, &CMagicGis_UpdateView::OnBuffer)
	ON_COMMAND(ID_SelectPoint, &CMagicGis_UpdateView::OnSelectpoint)
	ON_COMMAND(ID_MovePoint, &CMagicGis_UpdateView::OnMovepoint)
	ON_COMMAND(ID_Zoomout, &CMagicGis_UpdateView::OnZoomout)
	ON_COMMAND(ID_Move, &CMagicGis_UpdateView::OnMove)
	ON_COMMAND(ID_Reset, &CMagicGis_UpdateView::OnReset)
	ON_COMMAND(ID_Zoomin, &CMagicGis_UpdateView::OnZoomin)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_COMMAND(ID_ChooseLine, &CMagicGis_UpdateView::OnChooseline)
	ON_COMMAND(ID_MoveLine, &CMagicGis_UpdateView::OnMoveline)
	ON_COMMAND(ID_CutLine, &CMagicGis_UpdateView::OnCutline)
	ON_COMMAND(ID_SquaredeleteLine, &CMagicGis_UpdateView::OnSquaredeleteline)
	ON_COMMAND(ID_SelectArea, &CMagicGis_UpdateView::OnSelectarea)
	ON_COMMAND(ID_Squaredeletearea, &CMagicGis_UpdateView::OnSquaredeletearea)
	ON_COMMAND(ID_MoveArea, &CMagicGis_UpdateView::OnMovearea)
	ON_COMMAND(ID_AddNote, &CMagicGis_UpdateView::OnAddnote)
	ON_COMMAND(ID_SelectNote, &CMagicGis_UpdateView::OnSelectnote)
	ON_COMMAND(ID_ModifyNote, &CMagicGis_UpdateView::OnModifynote)
	ON_COMMAND(ID_MoveNote, &CMagicGis_UpdateView::OnMovenote)
	ON_COMMAND(ID_DeleteNote, &CMagicGis_UpdateView::OnDeletenote)
	ON_COMMAND (ID_AddGeometries, &CMagicGis_UpdateView::OnAddgeometries)
	ON_COMMAND (ID_QueryGeometries, &CMagicGis_UpdateView::OnQuerygeometries)
END_MESSAGE_MAP()

// CMagicGis_UpdateView ����/����

CMagicGis_UpdateView::CMagicGis_UpdateView()
: radium(0)
{
	// TODO:  �ڴ˴����ӹ������
	m_ptBaseGisTool = NULL;

}

CMagicGis_UpdateView::~CMagicGis_UpdateView()
{
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
}

BOOL CMagicGis_UpdateView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO:  �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CView::PreCreateWindow(cs);
}

// CMagicGis_UpdateView ����

void CMagicGis_UpdateView::OnDraw(CDC* pDC)
{
	CMagicGis_UpdateDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)		
		return;
	CMagicGis_Point Point;
	CMagicGis_Area Area;
	CMagicGis_Line Line;
	CMagicGis_Note Note;
	int i = 0;
	int j = 0;
	for (i = 0; i<s_point.getSize(); i++)  // for ѭ������Ļ�ϵ���������ĵ�
	{
		for (j = 0; j<s_layer.getSize(); j++)
		{
			if (s_point.elements[i].layer != -1 && s_point.elements[i].layer == s_layer.elements[j].id&&s_layer.elements[j].isshow)
				Point.Draw(s_point.elements[i], pDC);
		}
	}
	for (i = 0; i<s_line.getSize(); i++)   // for ѭ������Ļ�ϵ������������
	{
		for (j = 0; j<s_layer.getSize(); j++)
		{
			if (s_line.elements[i].layer != -1 && s_line.elements[i].layer == s_layer.elements[j].id&&s_layer.elements[j].isshow)
				Line.Draw(s_line.elements[i], pDC);
		}
	}
	for (i = 0; i<s_Circle.getSize(); i++)   // for ѭ������Ļ�ϵ������������
	{
		for (j = 0; j<s_layer.getSize(); j++)
		{
			if (s_Circle.elements[i].layer != -1 && s_Circle.elements[i].layer == s_layer.elements[j].id&&s_layer.elements[j].isshow)
				Area.Draw(s_Circle.elements[i], pDC);
		}
	}
	for (i = 0; i<s_note.getSize(); i++)   // for ѭ������Ļ�ϵ����������ע��
	{
		for (j = 0; j<s_layer.getSize(); j++)
		{
			if (s_note.elements[i].layer != -1 && s_note.elements[i].layer == s_layer.elements[j].id&&s_layer.elements[j].isshow)
				Note.Draw(s_note.elements[i], pDC);
		}
	}

	// TODO:  �ڴ˴�Ϊ�����������ӻ��ƴ���
}


// CMagicGis_UpdateView ��ӡ


void CMagicGis_UpdateView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMagicGis_UpdateView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Ĭ��׼��
	return DoPreparePrinting(pInfo);
}

void CMagicGis_UpdateView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO:  ���Ӷ���Ĵ�ӡǰ���еĳ�ʼ������
}

void CMagicGis_UpdateView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO:  ���Ӵ�ӡ����е���������
}

void CMagicGis_UpdateView::OnRButtonUp(UINT nFlags, CPoint point)
{
	CDC *pDC = GetDC();
	if (m_ptBaseGisTool != NULL){
		if ((MenuID == 12) || (MenuID == 13) || (MenuID == 14)){
			KillTimer(1);
			KillTimer(2);
			m_ptBaseGisTool->Draw(s_point.elements[list], pDC);
			Isselectpoint = false;
			Isselectline = false;
			Isselectcircle = false;
			Isselectnote = false;
	}
		else if (MenuID == 22 || 23){
			KillTimer(3);
			KillTimer(4);
			m_ptBaseGisTool->Draw(s_line.elements[list], pDC);
			Isselectpoint = false;
			Isselectline = false;
			Isselectcircle = false;
			Isselectnote = false;
		}
		else if (MenuID==25){
			KillTimer(3);
			KillTimer(4);
			tag_linecut = 1;
			m_ptBaseGisTool->Draw(s_line.elements[list], pDC);
			Isselectpoint = false;
			Isselectline = false;
			Isselectcircle = false;
			Isselectnote = false;
		}
		else if ((MenuID == 34)||(MenuID=32)){
			KillTimer(5);
			KillTimer(6);
			m_ptBaseGisTool->Draw(s_Circle.elements[list], pDC);
			Isselectline = false;
		}
		m_ptBaseGisTool->RButtonUp(pDC, nFlags, point);
	}
	ReleaseDC(pDC);
	CView::OnRButtonUp(nFlags, point);
}

void CMagicGis_UpdateView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMagicGis_UpdateView ���

#ifdef _DEBUG
void CMagicGis_UpdateView::AssertValid() const
{
	CView::AssertValid();
}

void CMagicGis_UpdateView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMagicGis_UpdateDoc* CMagicGis_UpdateView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMagicGis_UpdateDoc)));
	return (CMagicGis_UpdateDoc*)m_pDocument;
}
#endif //_DEBUG


// CMagicGis_UpdateView ��Ϣ��������


void CMagicGis_UpdateView::OnAddpoint()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 11;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Point(this);
}


void CMagicGis_UpdateView::OnModifypoint()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 13;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Point(this);
}


void CMagicGis_UpdateView::OnDeletepoint()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 15;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Point(this);
}


void CMagicGis_UpdateView::OnAddline()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 21;
	Isselectline = false;
	m_ptBaseGisTool = new CMagicGis_Line(this);
}


void CMagicGis_UpdateView::OnModifyline()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 23;
	Isselectline = false;
	m_ptBaseGisTool = new CMagicGis_Line(this);
}


void CMagicGis_UpdateView::OnDeleteline()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{

		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 26;
	Isselectline = false;
	m_ptBaseGisTool = new CMagicGis_Line(this);
}


void CMagicGis_UpdateView::OnAddarea()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 31;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Area(this);
}


void CMagicGis_UpdateView::OnModifyarea()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 32;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Area(this);
}


void CMagicGis_UpdateView::OnDeletearea()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 33;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Area(this);
}


void CMagicGis_UpdateView::OnBuffer()
{
	// TODO:  �ڴ�����������������
	CMagicGis_UpdateDoc *pDoc = GetDocument();
	MenuID = 4;
	SetBuffer bufdlg;
	CDC *pDC = GetDC();
	if (bufdlg.DoModal() == IDOK)
	{
		radium = bufdlg.radius;
		if (bufdlg.action_type == 1)
		{
			MenuID = 41;
			CMagicGis_Point Point;
			Point.DrawBuffer(pDC, s_point, radium);
		}
		if (bufdlg.action_type == 2)
		{
			MenuID = 42;
			CMagicGis_Line Line;
			Line.DrawBuffer(pDC, s_line, radium, pDoc);
		}
		if (bufdlg.action_type == 3)
		{
			MenuID = 43;
			CMagicGis_Area Area;
			Area.DrawBuffer(pDC, s_Circle, radium, pDoc);
		}
	}
}


void CMagicGis_UpdateView::OnSelectpoint()
{
	// TODO:  �ڴ�����������������
	/*MenuID = 12;*/
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 12;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Point(this);
}


void CMagicGis_UpdateView::OnMovepoint()
{
	// TODO:  �ڴ�����������������
	/*MenuID = 14;*/
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 14;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Point(this);
}


void CMagicGis_UpdateView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
	CDC *pDC = GetDC();
	if (m_ptBaseGisTool != NULL){
		if (MenuID == 12 || MenuID == 13 || MenuID == 14){
			KillTimer(1);
			KillTimer(2);
			m_ptBaseGisTool->Draw(s_point.elements[list], pDC);
			SetTimer(1, 200, NULL);
			SetTimer(2, 250, NULL);
		}
		else if (MenuID == 15){
			KillTimer(1);
			KillTimer(2);
			m_ptBaseGisTool->Draw(s_point.elements[list], pDC);
		}
		else if (MenuID == 22 || MenuID == 23 || MenuID == 24){
			KillTimer(3);
			KillTimer(4);
			m_ptBaseGisTool->Draw(s_line.elements[list], pDC);
			SetTimer(3, 200, NULL);
			SetTimer(4, 250, NULL);
		}
		else if (MenuID == 26){
			KillTimer(3);
			KillTimer(4);
			m_ptBaseGisTool->Draw(s_line.elements[list], pDC);
		}
		else if (MenuID == 34 || MenuID == 32 || MenuID == 36){
			KillTimer(5);
			KillTimer(6);
			m_ptBaseGisTool->Draw(s_Circle.elements[list], pDC);
			SetTimer(5, 200, NULL);
			SetTimer(6, 250, NULL);
		}
		else if (MenuID == 33){
			KillTimer(5);
			KillTimer(6);
			m_ptBaseGisTool->Draw(s_Circle.elements[list], pDC);
		}
		else if (MenuID == 27 || MenuID == 111 || MenuID == 222||MenuID==35){
			m_startp = point;
			CRectTracker Tracker;
			if (Tracker.TrackRubberBand(this, point, TRUE))
			{
				CRect rt;
				// ��ȡ�����ľ���  
				Tracker.GetTrueRect(&rt);
				// ��ȡ������������Ǹ������  
				CPoint UpPt = GetOtherPoint(rt, point);
				LPARAM lp = MAKELPARAM(UpPt.x, UpPt.y);
				// �������������Ϣ  
				this->SendMessage(WM_LBUTTONUP, NULL, lp);
			}
		}
		else if (MenuID==52 || MenuID==53 || MenuID==54)
		{
			KillTimer(7);
			KillTimer(8);
			m_ptBaseGisTool->Draw(s_note.elements[list], pDC);
			SetTimer(7, 200, NULL);
			SetTimer(8, 250, NULL);
		}
		else if (MenuID==55){
			KillTimer(7);
			KillTimer(8);
			m_ptBaseGisTool->Draw(s_note.elements[list], pDC);
		}
		else if (MenuID == 44){
			m_startp = point;
			SetCursor(LoadCursor(NULL, IDC_SIZEALL));
			m_bLBtnDown = true;
		}
		m_ptBaseGisTool->LButtonDown(pDC, nFlags, point);
	}
	ReleaseDC(pDC);
	CView::OnLButtonDown(nFlags, point);
}


void CMagicGis_UpdateView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
	CDC *pDC = GetDC();
	if (m_ptBaseGisTool != NULL){
		if (MenuID == 111)
		{
			m_lastp = point;
			m_ptBaseGisTool->CBaseTool::Zoomin(pDC);
			OnRefresh();
		}
		else if (MenuID == 222)
		{
			m_lastp = point;
			m_ptBaseGisTool->CBaseTool::Zoomout(pDC);
			OnRefresh();
		}
		else if (MenuID == 444){
			if (m_bLBtnDown)
			{
				int i, j;
				m_bLBtnDown = false;
				/*for (i = 0; i<s_point.getSize(); i++)
				{
					Operation.Connectiondb();
					Operation.modifyPoint(s_point.elements[i]);
				}
				for (i = 0; i<s_line.getSize(); i++)
				{
					for (j = 0; j<s_line.elements[i].getSize(); j++)
					{
						Operation.Connectiondb();
						Operation.modifyLine(s_line.elements[i]);
					}
				}
				for (i = 0; i<s_Circle.getSize(); i++)
				{
					for (j = 0; j<s_Circle.elements[i].getSize(); j++)
					{
						Operation.Connectiondb();
						Operation.modifyCircle(s_Circle.elements[i]);
					}
				}*/
				/*for (i = 0; i<s_note.getSize(); i++)
				{
					Operation.Connectiondb();
					Operation.modifyNote(s_note.elements[i]);
				}*/
			}
		}
		else
		{
			m_ptBaseGisTool->LButtonUp(pDC, nFlags, point);
		}
	}
	ReleaseDC(pDC);
	CView::OnLButtonUp(nFlags, point);
}


void CMagicGis_UpdateView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
	CDC *pDC = GetDC();
	if (m_ptBaseGisTool != NULL){
		OnDraw(pDC);
		m_ptBaseGisTool->MouseMove(pDC, nFlags, point);
		if (MenuID==444)
		{
			if (m_bLBtnDown)
			{
				SetCursor(LoadCursor(NULL, IDC_SIZEALL));
				OnRefresh();
				m_lastp = point;
				m_ptBaseGisTool->CBaseTool::OnMove(pDC);
				m_startp = m_lastp;
			}
		}
	}
	ReleaseDC(pDC);
	CView::OnMouseMove(nFlags, point);
}


void CMagicGis_UpdateView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
	switch (nIDEvent)
	{
	case 1:
	{
			  if (Isselectpoint)
			  {
				  CDC *pDC = GetDC();
				  GeoPoint temp = selectpoint;
				  temp.color = RGB(0, 0, 255);
				  m_ptBaseGisTool->Draw(temp, pDC);
				  ReleaseDC(pDC);
				  break;
			  }
	}
	case 2:
	{
			  if (Isselectpoint)
			  {
				  CDC *pDC = GetDC();
				  GeoPoint temp = selectpoint;
				  temp.color = RGB(255, 0, 0);
				  m_ptBaseGisTool->Draw(temp, pDC);
				  ReleaseDC(pDC);
				  break;
			  }
	}
	case 3:
	{
		if (Isselectline)
		{
		CDC *pDC = GetDC();
		GeoLine temp = selectline;
		temp.color = RGB(0, 0, 255);
		m_ptBaseGisTool->Draw(temp, pDC);
		ReleaseDC(pDC);
		break;
		}
	}
	case 4:
	{
		if (Isselectline)
		{
		CDC *pDC = GetDC();
		GeoLine temp = selectline;
		temp.color = RGB(255, 0, 0);
		m_ptBaseGisTool->Draw(temp, pDC);
		ReleaseDC(pDC);
		break;
		}
	}
	case 5:
	{
		if (Isselectcircle)
		{
		CDC *pDC = GetDC();
		GeoCircle temp = selectcircle;
		temp.color = RGB(0, 0, 255);
		m_ptBaseGisTool->Draw(temp, pDC);
		ReleaseDC(pDC);
		break;
		}
	}
	case 6:
	{
		if (Isselectcircle)
		{
		CDC *pDC = GetDC();
		GeoCircle temp = selectcircle;
		temp.color = RGB(255, 0, 0);
		m_ptBaseGisTool->Draw(temp, pDC);
		ReleaseDC(pDC);
		break;
		}
	}
	case 7:
	{
		if (Isselectnote)
		{
		CDC *pDC = GetDC();
		GeoNote temp = selectnote;
		temp.color = RGB(0, 0, 255);
		m_ptBaseGisTool->Draw(temp, pDC);
		ReleaseDC(pDC);
		break;
		}
	}
	case 8:
	{
		if (Isselectnote)
		{
		CDC *pDC = GetDC();
		GeoNote temp = selectnote;
		temp.color = RGB(255, 0, 0);
		m_ptBaseGisTool->Draw(temp, pDC);
		ReleaseDC(pDC);
		break;
		}
	}
	}
	CView::OnTimer(nIDEvent);
}

void CMagicGis_UpdateView::OnRefresh()
{
	// TODO: �ڴ�����������������
	Invalidate();
}


void CMagicGis_UpdateView::OnReset()
{
	// TODO: �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	CDC *pDC = GetDC();
	MenuID = 333;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CBaseTool();
	CRect rect;
	GetWindowRect(&rect);
	m_ptBaseGisTool->CBaseTool::OnReset(rect, pDC);
	OnRefresh();
	ReleaseDC(pDC);

}


void CMagicGis_UpdateView::OnZoomin()
{
	// TODO: �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 111;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CBaseTool();
}


void CMagicGis_UpdateView::OnZoomout()
{
	// TODO: �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 222;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CBaseTool();
}


void CMagicGis_UpdateView::OnMove()
{
	// TODO: �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 444;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CBaseTool();
}


void CMagicGis_UpdateView::OnChooseline()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 22;
	tag_linecut = 1;
	Isselectline = false;
	m_ptBaseGisTool = new CMagicGis_Line(this);
}


void CMagicGis_UpdateView::OnMoveline()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 24;
	Isselectline = false;
	m_ptBaseGisTool = new CMagicGis_Line(this);
}


void CMagicGis_UpdateView::OnCutline()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 25;
	tag_linecut = -1;
	Isselectline = false;
	m_ptBaseGisTool = new CMagicGis_Line(this);
}


void CMagicGis_UpdateView::OnSquaredeleteline()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 27;
	Isselectline = false;
	m_ptBaseGisTool = new CMagicGis_Line(this);
}


void CMagicGis_UpdateView::OnSelectarea()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 34;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Area(this);
}


void CMagicGis_UpdateView::OnSquaredeletearea()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 35;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Area(this);
}


void CMagicGis_UpdateView::OnMovearea()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 36;
	Isselectpoint = false;
	Isselectline = false;
	Isselectcircle = false;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Area(this);
}

/////////////////////////////////////////////////////////
void CMagicGis_UpdateView::OnAddnote()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 51;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Note(this);
}


void CMagicGis_UpdateView::OnSelectnote()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 52;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Note(this);
}


void CMagicGis_UpdateView::OnModifynote()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 53;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Note(this);
}


void CMagicGis_UpdateView::OnMovenote()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 54;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Note(this);
}


void CMagicGis_UpdateView::OnDeletenote()
{
	// TODO:  �ڴ�����������������
	if (m_ptBaseGisTool != NULL)
	{
		delete m_ptBaseGisTool;
		m_ptBaseGisTool = NULL;
	}
	MenuID = 55;
	Isselectnote = false;
	m_ptBaseGisTool = new CMagicGis_Note(this);
}
/////////////////////////////////////////////////////////////

void CMagicGis_UpdateView::OnAddgeometries ( )
{
	// TODO: �ڴ�����������������
	MyDataBase myDB;
	myDB.m_InsertGeometries (1, 1, (CString)"POINT", (CString)"(20,20)", 1, RGB (0, 0, 0));
	myDB.m_InsertGeometries (1, 2, (CString)"POINT", (CString)"(50,50)", 1, RGB (255, 0, 0));
	myDB.m_InsertGeometries (1, 3, (CString)"POINT", (CString)"(120,120)", 2, RGB (0, 0, 0));
	myDB.m_InsertGeometries (2, 4, (CString)"POINT", (CString)"(80,70)", 2, RGB (0, 0, 0));
	myDB.m_InsertGeometries (2, 5, (CString)"LINESTRING", (CString)"(30 50, 80 80, 140 70)", 1, RGB (255, 0, 0));
	myDB.m_InsertGeometries (3, 6, (CString)"LINESTRING", (CString)"(40 50, 20 80, 120 130)", 2, RGB (0, 0, 0));
	AfxMessageBox ((CString)"���ӳɹ�!");
}




void CMagicGis_UpdateView::OnQuerygeometries ( )
{
	// TODO: �ڴ�����������������
	DialogShowQuery dialog;
	dialog.DoModal ( );
	return;
}
