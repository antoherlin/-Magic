#include "stdafx.h"
#include "MagicGis_Line.h"
#include "Handlefunction.h"
#include "MagicGis_UpdateDoc.h"

extern "C" BOOL WINAPI LineDlg(int &L_mark, int &L_type, int &L_width, COLORREF &L_color);


CMagicGis_Line::CMagicGis_Line(void)
{
	line.width = 1;
	line.color = RGB(0, 0, 0);
	line.type = 0;
	line.layer = -1;
}

CMagicGis_Line::CMagicGis_Line(CView* ptView)
{
	line.width = 1;
	line.color = RGB(0, 0, 0);
	line.type = 0;
	line.layer = -1;
	m_ptView = ptView;
	m_step = 0;
	m_lastStart.x = 0;
	m_lastStart.y = 0;
	m_lastEnd.x = 0;
	m_lastEnd.y = 0;
	if (MenuID == 21)
	{
		int mark;
		LineDlg(mark, line.type, line.width, line.color);
		int x = 0;

	}
}
CMagicGis_Line::~CMagicGis_Line(void)
{
}
int CMagicGis_Line::LButtonDown(CDC *pDC, UINT nFlags, CPoint point)
{
	CPen pen(line.type, line.width, line.color);
	pOldPen = pDC->SelectObject(&pen);
	switch (MenuID){
	case 21:
		if (m_step != 0)
		{
			pDC->MoveTo(m_lastStart);
			pDC->LineTo(point);
		}
		m_step++;
		m_lastStart = point;
		line.Push(m_lastStart);
		break;
	case 22:
		Select(point, pDC);
		break;
	case 23:
		Modify(point, pDC);
		break;
	case 24:
		Move(point, pDC);
		break;
	case 26:
		Delete(point, pDC);
		break;
	case 25:
		Cut(point, pDC);
		break;
	}
	pDC->SelectObject(pOldPen);
	return (1);
}

int CMagicGis_Line::LButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID)
	{
	case 24:
		if (m_bLBtnDown)
		{
			m_bLBtnDown = false;
			s_line.elements[list] = m_lineMouse;
		}
		break;
	case 27:
		m_lastp = point;
		SquareDelete(pDC);
	}
	return (1);
}

int CMagicGis_Line::MouseMove(CDC *pDC, UINT nFlags, CPoint point)
{
	CPen pen(line.type, line.width, line.color);
	pOldPen = pDC->SelectObject(&pen);
	switch (MenuID)
	{
	case 21:
		if (m_step != 0)
		{
			pDC->SetROP2(R2_NOTXORPEN);
			if (m_lastEnd.x != 0 && m_lastEnd.y != 0)
			{
				pDC->MoveTo(m_lastStart);
				pDC->LineTo(m_lastEnd);
			}
			pDC->MoveTo(m_lastStart);
			pDC->LineTo(point);
			m_lastEnd = point;
		}
		break;
	case 24:
		if (m_bLBtnDown)
		{
			GeoLine temp_Line = m_lineMouse;
			temp_Line.color = RGB(255, 255, 255);
			Draw(temp_Line, pDC);
			CPoint temp_point = m_lastStart;
			CSize offset(point - temp_point);
			for (int i = 0; i<m_lineMouse.getSize(); i++)
				m_lineMouse.data[i] += offset;
			m_lastStart = point;
			Draw(m_lineMouse, pDC);
			selectline = m_lineMouse;
		}
		break;

	}
	pDC->SelectObject(pOldPen);
	return (1);
}
int CMagicGis_Line::RButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID)
	{
	case 21:
		m_step = 0;
		m_lastStart.x = 0;
		m_lastStart.y = 0;
		m_lastEnd.x = 0;
		m_lastEnd.y = 0;
		line.Push(point);
		line.layer = s_layer.elements[editlayer].id;
		s_line.Push(line);
		line.data.clear();
		break;
	}
	return (1);
}




void CMagicGis_Line::Draw(GeoLine &line, CDC *pDC){

	CPen pen(line.type, line.width, line.color);
	pOldPen = pDC->SelectObject(&pen);
	for (int i = 0; i<line.getSize() - 1; i++)
	{
		pDC->MoveTo(line.data[i]);
		pDC->LineTo(line.data[i + 1]);
	}
	pDC->SelectObject(pOldPen);
}


void CMagicGis_Line::Select(CPoint &point, CDC *pDC){
	Isselectline = false;
	int i;
	for (i = 0; i<s_line.getSize(); i++)
	{
		if (OnMouseSelectLine(point, s_line.elements[i])){
			list = i;
			selectline = s_line.elements[i];
			Isselectline = true;
			break;
		}
	}
	if (Isselectline){
		if (tag_linecut == -1){
			MenuID = 25;
			AfxMessageBox(_T("�߳ɹ�ѡ��,��ѡ����ϴ���"));
		}
	}

}

void CMagicGis_Line::Modify(CPoint &point, CDC *pDC){
	tag_linecut = 1;
	Select(point, pDC);
	if (Isselectline){
		int mark, type, width;
		COLORREF color;
		LineDlg(mark, type,width,color);
		if (mark==0){
			s_line.elements[list].color = RGB(255, 255, 255);
			Draw(s_line.elements[list], pDC);
			s_line.elements[list].type = type;
			s_line.elements[list].width = width;
			s_line.elements[list].color = color;
			/*Operation.modifyLine(s_line.elements[list]);*/
			Draw(s_line.elements[list], pDC);
			selectline = s_line.elements[list];
		}
	}
}

void CMagicGis_Line::Move(CPoint &point, CDC *pDC){
	tag_linecut = 1;
	Select(point, pDC);
	if (Isselectline)
	{
		m_bLBtnDown = true;
		m_lastStart = point;
		m_lineMouse = s_line.elements[list];
		s_line.elements[list].color = RGB(255, 255, 255);
	}
}


void CMagicGis_Line::Delete(CPoint &point, CDC *pDC){
	tag_linecut = 1;
	Select(point, pDC);
	if (Isselectline)
	{
		if (MessageBox(NULL, _T("ȷ��ɾ��������"), _T("ɾ����"), MB_OKCANCEL | MB_ICONWARNING) == IDOK){
			s_line.elements[list].color = RGB(255, 255, 255);
			Draw(s_line.elements[list], pDC);
			s_line.delete_elements(list);
			Isselectline = false;
		}
	}
}


void CMagicGis_Line::Cut(CPoint &point, CDC *pDC){
	if (Isselectline)
	{
		bool p = true;
		for (int i = 0; i < s_line.elements[list].getSize(); i++)
		{
			rect_point.SetRect((int)s_line.elements[list].data[i].x - 4, (int)s_line.elements[list].data[i].y - 4, (int)s_line.elements[list].data[i].x + 4, (int)s_line.elements[list].data[i].y + 4);
			if (rect_point.PtInRect(point))
			{
				GeoLine temp_line;
				temp_line.type = s_line.elements[list].type;
				temp_line.color = s_line.elements[list].color;
				temp_line.width = s_line.elements[list].width;
				for (int j = i; j < s_line.elements[list].getSize(); j++)
				{
					temp_line.Push(s_line.elements[list].data[j]);
				}
				Draw(temp_line, pDC);
				temp_line.layer = s_layer.elements[editlayer].id;
				//t/*emp_line.id = Operation.addLine(temp_line);*/
				s_line.Push(temp_line);
				s_line.elements[list].data.erase(s_line.elements[list].data.begin() + i + 1, s_line.elements[list].data.end());
				/*Operation.modifyLine(s_line.elements[list]);*/
				p = false;
				Isselectline = false;
				MenuID = 22;
				tag_linecut = -1;
				AfxMessageBox(_T("���Ѿ��ɹ����ϸ��ߣ�"));
				break;
			}
		}
		if (p)
		{
			AfxMessageBox(_T("������ѡ����ϴ���"));
		}
	}

}


void CMagicGis_Line::SquareDelete(CDC *pDC)
{
	bool t;
	for (int i = 0; i<s_line.getSize(); i++)
	{
		t = true;
		for (int j = 0; j<s_line.elements[i].getSize(); j++)
		{
			if (OnMouseDelete(s_line.elements[i].data[j].x, s_line.elements[i].data[j].y, m_startp.x, m_startp.y, m_lastp.x, m_lastp.y))
			{
				t = false;
				break;
			}
		}
		if (t)
		{
			s_line.elements[i].color = RGB(255, 255, 255);
			Draw(s_line.elements[i], pDC);
			//O/*peration.deleteLine(s_line.elements[i]);*/
			s_line.delete_elements(i);
			i--;
		}
	}
}


void CMagicGis_Line::DrawBuffer(CDC * pDC, SeqStack<GeoLine> & m_Line, int radium,CMagicGis_UpdateDoc *pDoc)
{
	CPen pen(PS_SOLID, 1, RGB(0, 255, 0));
	CPen *pOldPen = pDC->SelectObject(&pen);
	CBrush brush(RGB(0, 255, 0));
	CBrush *pOldBrush = pDC->SelectObject(&brush);
	pDC->SetROP2(R2_COPYPEN);
	for (int i = 0; i < m_Line.getSize(); i++)
	{
		int numPointOfLine = m_Line.elements[i].getSize();
		if (numPointOfLine > 2)
		{
			for (int j = 0; j < numPointOfLine - 1; j++)
			{
				CPoint* point = pDoc->CreateBufferEdge(m_Line.elements[i].data[j], m_Line.elements[i].data[j+1], radium);
				pDoc->PointNum = numPointOfLine;
				for (int j = 0; j < pDoc->PointNum - 1; j++)
				{
					pDC->MoveTo(point[j]); pDC->LineTo(point[j + 1]);
				}
				pDC->Polygon(point, pDoc->PointNum - 1);//������亯��
				pDC->Ellipse(m_Line.elements[i].data[j].x - radium, m_Line.elements[i].data[j].y + radium, m_Line.elements[i].data[j].x + radium, m_Line.elements[i].data[j].y - radium);//�Զ˵����
				pDC->Ellipse(m_Line.elements[i].data[j + 1].x - radium, m_Line.elements[i].data[j + 1].y + radium, m_Line.elements[i].data[j + 1].x + radium, m_Line.elements[i].data[j + 1].y - radium);//    ���������

				pDoc->PointNum = 0;
				if (point != NULL)
					delete point;
			}
		}
		else if (numPointOfLine == 2)
		{
			CPoint* point = pDoc->CreateBufferEdge(m_Line.elements[i].data[0], m_Line.elements[i].data[1], radium);
			pDoc->PointNum = 5;
			for (int j = 0; j < pDoc->PointNum - 1; j++)
			{
				pDC->MoveTo(point[j]); pDC->LineTo(point[j + 1]);
			}
			pDC->Polygon(point, pDoc->PointNum - 1);//������亯��
			pDC->Ellipse(m_Line.elements[i].data[0].x - radium, m_Line.elements[i].data[0].y + radium, m_Line.elements[i].data[0].x + radium, m_Line.elements[i].data[0].y - radium);//�Զ˵����
			pDC->Ellipse(m_Line.elements[i].data[1].x - radium, m_Line.elements[i].data[1].y + radium, m_Line.elements[i].data[1].x + radium, m_Line.elements[i].data[1].y - radium);//    ���������
			pDoc->PointNum = 0;
			if (point != NULL)
				delete point;
		}
		else
		{
			AfxMessageBox(_T("ͼ������"), MB_ICONEXCLAMATION);
			return;
		}
	}
	pDC->SelectObject(pOldPen);//�ָ����ʻ�ˢ����
	pDC->SelectObject(pOldBrush);

	for (int i = 0; i < m_Line.getSize(); i++)  //�ػ�ԭʼ��
	{
		int k = m_Line.elements[i].getSize();
		if (k > 2)
		{
			for (int j = 0; j<k - 1; j++)
			{
				pDC->MoveTo(m_Line.elements[i].data[j]); pDC->LineTo(m_Line.elements[i].data[j+1]);
			}
		}
		else if (k == 2)
		{
			pDC->MoveTo(m_Line.elements[i].data[0]); pDC->LineTo(m_Line.elements[i].data[1]);
		}
	}
}
