
// MagicGis_UpdateView.h : CMagicGis_UpdateView ��Ľӿ�
//

#pragma once
#include "BaseTool.h"
#include "MagicGis_Area.h"
#include "MagicGis_Line.h"
#include "MagicGis_Point.h"
////////////////////////////////////////////
#include "MagicGis_Note.h"


class CMagicGis_UpdateView : public CView
{
protected: // �������л�����
	CMagicGis_UpdateView();
	DECLARE_DYNCREATE(CMagicGis_UpdateView)

// ����
public:
	CMagicGis_UpdateDoc* GetDocument() const;
	CBaseTool*	m_ptBaseGisTool;
// ����
public:

// ��д
public:
	virtual void OnDraw(CDC* pDC);  // ��д�Ի��Ƹ���ͼ
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// ʵ��
public:
	virtual ~CMagicGis_UpdateView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	/*afx_msg void OnAddline();*/
	//afx_msg void OnAddpoint();
	afx_msg void OnAddpoint();
	afx_msg void OnModifypoint();
	afx_msg void OnDeletepoint();
	afx_msg void OnAddline();
	afx_msg void OnModifyline();
	afx_msg void OnDeleteline();
	afx_msg void OnAddarea();
	afx_msg void OnModifyarea();
	afx_msg void OnDeletearea();
	afx_msg void OnBuffer();
	afx_msg void OnSelectpoint();
	afx_msg void OnMovepoint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnZoomin();
	afx_msg void OnZoomout();
	afx_msg void OnReset();
	afx_msg void OnMove();
	afx_msg void OnRefresh();
	int radium;
	afx_msg void OnChooseline();
	afx_msg void OnMoveline();
	afx_msg void OnCutline();
	afx_msg void OnSquaredeleteline();
	afx_msg void OnSelectarea();
	afx_msg void OnSquaredeletearea();
	afx_msg void OnMovearea();
	afx_msg void OnAddnote();
	afx_msg void OnSelectnote();
	afx_msg void OnModifynote();
	afx_msg void OnMovenote();
	afx_msg void OnDeletenote();
	afx_msg void OnAddgeometries ( );
	afx_msg void OnQuerygeometries ( );
};

#ifndef _DEBUG  // MagicGis_UpdateView.cpp �еĵ��԰汾
inline CMagicGis_UpdateDoc* CMagicGis_UpdateView::GetDocument() const
   { return reinterpret_cast<CMagicGis_UpdateDoc*>(m_pDocument); }
#endif

