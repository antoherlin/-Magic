#pragma once
#include "resource.h"

// CPointDlg �Ի���

class CPointDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CPointDlg)

public:
	CPointDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPointDlg();

// �Ի�������
	enum { IDD = IDD_EditPoint };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int p_r;
	int p_g;
	int p_b;
	int pointtype;
	afx_msg void OnBnClickedSqu();
	afx_msg void OnBnClickedTri();
	afx_msg void OnBnClickedCir();
	afx_msg void OnBnClickedchoosecolor();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
