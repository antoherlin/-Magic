// AddLayer.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MagicGis_Update.h"
#include "AddLayer.h"
#include "afxdialogex.h"


// CAddLayer �Ի���

IMPLEMENT_DYNAMIC(CAddLayer, CDialogEx)

CAddLayer::CAddLayer(CWnd* pParent /*=NULL*/)
	: CDialogEx(CAddLayer::IDD, pParent)
{

}

CAddLayer::~CAddLayer()
{
}

void CAddLayer::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CAddLayer, CDialogEx)
END_MESSAGE_MAP()


// CAddLayer ��Ϣ��������
