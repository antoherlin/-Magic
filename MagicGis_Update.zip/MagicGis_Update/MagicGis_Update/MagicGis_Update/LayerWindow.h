#pragma once
#include "CatalogTree.h"
class CLayerWindow:public CDockablePane
{
public:
	CLayerWindow();
	~CLayerWindow();
};

