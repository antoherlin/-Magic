#pragma once
class CCatalogTree
{
public:
	CCatalogTree();
	~CCatalogTree();
};

