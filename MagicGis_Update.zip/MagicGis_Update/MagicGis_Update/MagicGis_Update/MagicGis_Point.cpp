#pragma once
#include "stdafx.h"
#include "MagicGis_Point.h"
#include "PointDlg.h"

extern "C"	 BOOL WINAPI PointDlg(int &type, COLORREF &color, int mark);

CMagicGis_Point::CMagicGis_Point(void)
{
	p.color = RGB(0, 0, 0);
	p.layer = -1;
	p.type = 0;
}

CMagicGis_Point::CMagicGis_Point(CView* ptView)
{
	p.color = RGB(0, 0, 0);
	p.type = 0;
	m_ptView = ptView;
	if (MenuID == 11)
	{
		int mark=0;
		PointDlg(p.type, p.color,mark);
	}
}

CMagicGis_Point::~CMagicGis_Point(void)
{

}

int CMagicGis_Point::LButtonDown(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID){
	case 11:
		p.mpoint = point;
		Draw(p, pDC);
		p.layer = s_layer.elements[editlayer].id;
		/*p.id = Operation.addPoint(p);*/
		s_point.Push(p);
		break;
	case 12:
		Draw(selectpoint, pDC);
		p.mpoint = point;
		SelectPoint(p, pDC);
		break;
	case 13:
		p.mpoint = point;
		ModifyPoint(p, pDC);
		break;
	case 14:
		p.mpoint = point;
		MovePoint(p, pDC);
		break;
	case 15:
		p.mpoint = point;
		DeletePoint(p, pDC);
		break;
	}
	return (1);
}

int CMagicGis_Point::MouseMove(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID){
	case 14:
		if (m_bLBtnDown) {
			GeoPoint temp_point = m_pointMouse;
			temp_point.color = RGB(255, 255, 255);
			Draw(temp_point, pDC);
			m_pointMouse.mpoint = point;
			Draw(m_pointMouse, pDC);
			selectpoint = m_pointMouse;
		}
		break;
	}
	return (1);
}

int CMagicGis_Point::LButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID){
	case 14:
		if (m_bLBtnDown)
		{
			m_bLBtnDown = false;
			s_point.elements[list] = m_pointMouse;
			/*Operation.modifyPoint(s_point.elements[list]);*/
		}
		break;
	}
	return (1);

}

int CMagicGis_Point::RButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{

	return (1);
}

void CMagicGis_Point::Draw(GeoPoint &point, CDC *pDC){
	if (point.type == 1){    //���ε�
		CPen pen(PS_SOLID, 6, point.color);
		pDC->SelectObject(pen);
		CBrush *pBrush = new CBrush(point.color);
		pDC->SelectObject(&pBrush);
		pDC->Rectangle(point.mpoint.x - 1, point.mpoint.y - 1, point.mpoint.x + 1, point.mpoint.y + 1);
	}
	if (point.type == 2){          //���ǵ�
		pDC->SetPixel(point.mpoint.x, point.mpoint.y, point.color);
		pDC->SetPixel(point.mpoint.x, point.mpoint.y - 1, point.color);
		pDC->SetPixel(point.mpoint.x, point.mpoint.y - 2, point.color);
		pDC->SetPixel(point.mpoint.x, point.mpoint.y + 1, point.color);
		pDC->SetPixel(point.mpoint.x, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x + 1, point.mpoint.y, point.color);
		pDC->SetPixel(point.mpoint.x - 1, point.mpoint.y, point.color);
		pDC->SetPixel(point.mpoint.x - 2, point.mpoint.y, point.color);
		pDC->SetPixel(point.mpoint.x + 2, point.mpoint.y, point.color);
		pDC->SetPixel(point.mpoint.x + 1, point.mpoint.y - 1, point.color);
		pDC->SetPixel(point.mpoint.x - 1, point.mpoint.y + 1, point.color);
		pDC->SetPixel(point.mpoint.x + 1, point.mpoint.y + 1, point.color);
		pDC->SetPixel(point.mpoint.x - 1, point.mpoint.y - 1, point.color);
		pDC->SetPixel(point.mpoint.x - 2, point.mpoint.y + 1, point.color);
		pDC->SetPixel(point.mpoint.x + 2, point.mpoint.y + 1, point.color);
		pDC->SetPixel(point.mpoint.x - 3, point.mpoint.y + 1, point.color);
		pDC->SetPixel(point.mpoint.x + 3, point.mpoint.y + 1, point.color);
		pDC->SetPixel(point.mpoint.x - 3, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x - 2, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x - 1, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x + 1, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x + 2, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x + 3, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x - 4, point.mpoint.y + 2, point.color);
		pDC->SetPixel(point.mpoint.x + 4, point.mpoint.y + 2, point.color);
	}
	if (point.type == 3){      //Բ��
		CPen pen(PS_SOLID, 6, point.color);
		pDC->SelectObject(pen);
		CBrush *pBrush = new CBrush(point.color);
		pDC->SelectObject(&pBrush);
		pDC->Ellipse(point.mpoint.x - 3, point.mpoint.y - 3, point.mpoint.x + 3, point.mpoint.y + 3);
	}
}

void CMagicGis_Point::SelectPoint(GeoPoint &point, CDC *pDC){
	for (int i = 0; i<s_point.getSize(); i++)
	{
		rect_point.SetRect((int)s_point.elements [i].mpoint.x - 4, (int)s_point.elements[i].mpoint.y - 4, (int)s_point.elements[i].mpoint.x + 4, (int)s_point.elements[i].mpoint.y + 4);
		if (rect_point.PtInRect(point.mpoint))
		{
			list = i;
			selectpoint = s_point.elements[i];
			Isselectpoint = true;
			break;
		}
	}
}

void CMagicGis_Point::ModifyPoint(GeoPoint &point, CDC *pDC){
	SelectPoint(point, pDC);
	if (Isselectpoint){
		int mark=0,type;
		COLORREF color;
		PointDlg(type, color, mark);
		if (mark==0){
			s_point.elements[list].color = RGB(255, 255, 255);
			Draw(s_point.elements[list], pDC);
			s_point.elements[list].type = type;
			s_point.elements[list].color = color;
			/*Operation.modifyPoint(s_point.elements[list]);*/
			Draw(s_point.elements[list], pDC);
			selectpoint = s_point.elements[list];
		}
	}
}

void CMagicGis_Point::MovePoint(GeoPoint &point, CDC *pDC){
	SelectPoint(point, pDC);
	if (Isselectpoint)
	{
		m_bLBtnDown = true;
		m_pointMouse = s_point.elements[list];
		s_point.elements[list].color = RGB(255, 255, 255);
	}
}

void CMagicGis_Point::DeletePoint(GeoPoint &point, CDC *pDC){
	SelectPoint(point, pDC);
	if (Isselectpoint)
	{
		if ((MessageBox(NULL, _T("ȷ��ɾ���õ㣿"), _T("ɾ����"), MB_OKCANCEL | MB_ICONWARNING))==IDOK){
		s_point.elements[list].color = RGB(255, 255, 255);
		Draw(s_point.elements[list], pDC);
		/*Operation.deletePoint(s_point.elements[list]);*/
		s_point.delete_elements(list);
		Isselectpoint = false;
		}
	}
}


void CMagicGis_Point::DrawBuffer(CDC * pDC, SeqStack<GeoPoint> &s_p, int radium)
{
	CPen pen(PS_SOLID, 1, RGB(0, 255, 0));
	CPen *pOldPen = pDC->SelectObject(&pen);
	CBrush brush(RGB(0, 255, 0));
	CBrush *pOldBrush = pDC->SelectObject(&brush);
	pDC->SetROP2(R2_COPYPEN);
	int numOfObject = s_p.getSize();
	for (int i = 0; i < numOfObject; i++)
	{
		pDC->Ellipse(s_point.elements[i].mpoint.x - radium, s_point.elements[i].mpoint.y + radium, s_point.elements[i].mpoint.x + radium, s_point.elements[i].mpoint.y - radium);
	}
	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOldBrush);
}
