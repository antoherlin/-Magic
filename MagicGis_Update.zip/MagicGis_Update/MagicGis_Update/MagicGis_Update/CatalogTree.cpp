#include "stdafx.h"
#include "CatalogTree.h"


CCatalogTree::CCatalogTree()
{
}


CCatalogTree::~CCatalogTree()
{
}
