#include "stdafx.h"
#include "LayerWindow.h"


CLayerWindow::CLayerWindow()
{
}


CLayerWindow::~CLayerWindow()
{
}
