#include "stdafx.h"
#include "Magic_Struct.h"
