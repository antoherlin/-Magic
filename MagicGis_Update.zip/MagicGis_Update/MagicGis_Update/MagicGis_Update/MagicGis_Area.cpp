#include "stdafx.h"
#include "MagicGis_Area.h"
#include "Handlefunction.h"
#include "MagicGis_UpdateDoc.h"

extern "C"	 BOOL WINAPI AreaDlg(COLORREF &color, int &mark,int &type);

CMagicGis_Area::CMagicGis_Area(void)
{
	Area.color = RGB(0, 0, 0);
	Area.type = 0;
	Area.layer = -1;
}

CMagicGis_Area::CMagicGis_Area(CView* ptView)
{
	Area.color = RGB(0, 0, 0);
	Area.type = 0;
	Area.layer = -1;
	m_ptView = ptView;
	m_step = 0;
	m_startPnt.x = 0;
	m_startPnt.y = 0;
	m_lastPnt.x = 0;
	m_lastPnt.y = 0;
	if (MenuID == 31)
	{
		int mark, type;
		COLORREF color;
		AreaDlg(color, mark, type);
		if (mark==0){
			Area.type = type;
			Area.color =color;
		}
	}
}

CMagicGis_Area::~CMagicGis_Area(void)
{
	m_step = 0;
	m_startPnt.x = 0;
	m_startPnt.y = 0;
	m_lastPnt.x = 0;
	m_lastPnt.y = 0;
}

int CMagicGis_Area::LButtonDown(CDC *pDC, UINT nFlags, CPoint point)
{
	CBrush brush(Area.color);
	CPen pen(PS_SOLID, 1, Area.color);
	pOldBrush = pDC->SelectObject(&brush);
	switch (MenuID)
	{
	case 31:
		if (m_step != 0 && Area.type == 0)
		{
			m_step = m_startPnt.x = m_startPnt.y = m_lastPnt.x = m_lastPnt.y = 0;
		}
		else if (m_step != 0 && Area.type == 1)
		{
			m_step = m_startPnt.x = m_startPnt.y = m_lastPnt.x = m_lastPnt.y = 0;
		}
		else if (m_step != 0 && Area.type == 2)
		{
			pOldPen = pDC->SelectObject(&pen);
			pDC->MoveTo(m_startPnt);
			pDC->LineTo(point);
		}
		m_step++;
		m_startPnt = point;
		Area.Push(m_startPnt);
		break;
	case 34:
		SelectArea(point, pDC);
		break;
	case 32:
		ModifyArea(point, pDC);
		break;
	case 36:
		MoveArea(point, pDC);
		break;
	case 33:
		DeleteArea(point, pDC);
		break;
	}
	pDC->SelectObject(pOldBrush);
	return (1);
}

int CMagicGis_Area::LButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID)
	{
	case 31:
		if (m_step != 0 && (Area.type == 0 || Area.type == 1) && point.x != m_startPnt.x&&point.y != m_startPnt.y)
		{
			Area.Push(point);
			Area.layer = s_layer.elements[editlayer].id;
			/*Area.id=Operation.addCircle(Area);*/
			s_Circle.Push(Area);
			Area.data.clear();
			m_step = m_startPnt.x = m_startPnt.y = m_lastPnt.x = m_lastPnt.y = 0;
		}
		else if (m_step != 0 && (Area.type == 0 || Area.type == 1) && point.x == m_startPnt.x&&point.y == m_startPnt.y)
		{
			Area.data.clear();
			m_step = m_startPnt.x = m_startPnt.y = m_lastPnt.x = m_lastPnt.y = 0;
		}
		break;
	case 36:
		if (m_bLBtnDown)
		{
			m_bLBtnDown = false;
			s_Circle.elements[list] = m_circleMouse;
			/*Operation.modifyCircle(s_Circle.elements[list]);*/
		}
		break;
	case 35:
		m_lastPnt = point;
		SquareDeleteArea(pDC);
		break;
	}
	return (1);
}

int CMagicGis_Area::MouseMove(CDC *pDC, UINT nFlags, CPoint point)
{

	CBrush brush(Area.color);
	CPen pen(PS_SOLID, 1, Area.color);
	pOldBrush = pDC->SelectObject(&brush);
	switch (MenuID)
	{
	case 31:
		if (m_step != 0 && Area.type == 0)
		{
			pDC->SetROP2(R2_NOTXORPEN);
			if (m_lastPnt.x != 0 && m_lastPnt.y != 0)
				pDC->Ellipse(m_startPnt.x, m_startPnt.y, m_lastPnt.x, m_lastPnt.y);
			pDC->Ellipse(m_startPnt.x, m_startPnt.y, point.x, point.y);
			m_lastPnt = point;
		}
		else if (m_step != 0 && Area.type == 1)
		{
			pDC->SetROP2(R2_NOTXORPEN);
			if (m_lastPnt.x != 0 && m_lastPnt.y != 0)
				pDC->Rectangle(m_startPnt.x, m_startPnt.y, m_lastPnt.x, m_lastPnt.y);
			pDC->Rectangle(m_startPnt.x, m_startPnt.y, point.x, point.y);
			m_lastPnt = point;
		}
		else if (m_step != 0 && Area.type == 2)
		{
			pOldPen = pDC->SelectObject(&pen);
			pDC->SetROP2(R2_NOTXORPEN);
			if (m_lastPnt.x != 0 && m_lastPnt.y != 0)
			{
				pDC->MoveTo(m_startPnt);
				pDC->LineTo(m_lastPnt);
			}
			pDC->MoveTo(m_startPnt);
			pDC->LineTo(point);
			m_lastPnt = point;
		}
		break;
	case 36:
		if (m_bLBtnDown)
		{
			GeoCircle temp_Circle = m_circleMouse;
			temp_Circle.color = RGB(255, 255, 255);
			Draw(temp_Circle, pDC);
			CPoint temp_point = m_startPnt;
			CSize offset(point - temp_point);
			for (int i = 0; i<m_circleMouse.getSize(); i++)
				m_circleMouse.data[i] += offset;
			m_startPnt = point;
			Draw(m_circleMouse, pDC);
			selectcircle = m_circleMouse;
		}
		break;
	}
	pDC->SelectObject(pOldBrush);
	return (1);
}

int CMagicGis_Area::RButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{
	CBrush brush(Area.color);
	CPen pen(PS_SOLID, 1, Area.color);
	pOldBrush = pDC->SelectObject(&brush);
	switch (MenuID)
	{
	case 31:
		if (Area.type == 2){
			pOldPen = pDC->SelectObject(&pen);
			m_step = m_startPnt.x = m_startPnt.y = m_lastPnt.x = m_lastPnt.y = 0;
			int i;
			Area.Push(point);
			if (Area.getSize()>2){
				pDC->BeginPath();
				pDC->MoveTo(Area.data[0]);
				pDC->LineTo(Area.data[1]);
				for (i = 1; i<Area.getSize() - 1; i++)
				{
					pDC->LineTo(Area.data[i]);
					pDC->LineTo(Area.data[i + 1]);
				}
				pDC->LineTo(Area.data[i]);
				pDC->LineTo(Area.data[0]);
				pDC->EndPath();
				CRgn rgn;
				rgn.CreateFromPath(pDC);
				pOldBrush = pDC->SelectObject(&brush);
				pDC->FillRgn(&rgn, &brush);
				Area.layer = s_layer.elements[editlayer].id;
				/*Area.id=Operation.addCircle(Area);*/
				s_Circle.Push(Area);
			}
			Area.data.clear();
		}
		break;
	}
	pDC->SelectObject(pOldBrush);
	return (1);
}

void CMagicGis_Area::Draw(GeoCircle &Area, CDC *pDC)
{
	CBrush brush(Area.color);
	CPen pen(PS_SOLID, 1, Area.color);
	switch (Area.type)
	{
	case 0:
		pOldBrush = pDC->SelectObject(&brush);
		pDC->Ellipse(Area.data[0].x, Area.data[0].y, Area.data[1].x, Area.data[1].y);
		pOldPen = pDC->SelectObject(&pen);
		pDC->Ellipse(Area.data[0].x, Area.data[0].y, Area.data[1].x, Area.data[1].y);
		break;
	case 1:
		pOldBrush = pDC->SelectObject(&brush);
		pDC->Rectangle(Area.data[0].x, Area.data[0].y, Area.data[1].x, Area.data[1].y);
		pOldPen = pDC->SelectObject(&pen);
		pDC->Rectangle(Area.data[0].x, Area.data[0].y, Area.data[1].x, Area.data[1].y);
		break;
	case 2:
		int i;
		pOldPen = pDC->SelectObject(&pen);
		pDC->BeginPath();
		pDC->MoveTo(Area.data[0]);
		pDC->LineTo(Area.data[1]);
		for (i = 1; i<Area.getSize() - 1; i++)
		{
			pDC->LineTo(Area.data[i]);
			pDC->LineTo(Area.data[i + 1]);
		}
		pDC->LineTo(Area.data[i]);
		pDC->LineTo(Area.data[0]);
		pDC->EndPath();
		CRgn rgn;
		rgn.CreateFromPath(pDC);
		pOldBrush = pDC->SelectObject(&brush);
		pDC->FillRgn(&rgn, &brush);
		break;
	}
	pDC->SelectObject(pOldBrush);
}

void CMagicGis_Area::SelectArea(CPoint &point, CDC *pDC)
{
	Isselectcircle = false;
	int i;
	for (i = 0; i<s_Circle.getSize(); i++)
	{
		if (s_Circle.elements[i].type == 0 || s_Circle.elements[i].type == 1)
		{
			if (OnMouseSelectcircle01(point.x, point.y, s_Circle.elements[i].data[0].x, s_Circle.elements[i].data[0].y, s_Circle.elements[i].data[1].x, s_Circle.elements[i].data[1].y))
			{
				list = i;
				selectcircle = s_Circle.elements[i];
				Isselectcircle = true;
				break;
			}
		}
		else if (s_Circle.elements[i].type == 2)
		{
			if (OnMouseSelectcircle2(s_Circle.elements[i].getSize(), s_Circle.elements[i], point.x, point.y))
			{
				list = i;
				selectcircle = s_Circle.elements[i];
				Isselectcircle = true;
				break;
			}
		}
	}
}

void CMagicGis_Area::ModifyArea(CPoint &point, CDC *pDC){
	SelectArea(point, pDC);
	if (Isselectcircle){
		int mark=0, type=0;
		COLORREF color=RGB(255,255,255);
		AreaDlg(color, mark, type);
		if (mark==0){
			s_Circle.elements[list].color = RGB(255, 255, 255);
			Draw(s_Circle.elements[list], pDC);
			s_Circle.elements[list].type = type;
			s_Circle.elements[list].color = color;
			/*Operation.modifyCircle(s_Circle.elements[list]);*/
			Draw(s_Circle.elements[list], pDC);
			selectcircle = s_Circle.elements[list];

		}
	}
}

void CMagicGis_Area::MoveArea(CPoint &point, CDC *pDC){
	SelectArea(point, pDC);
	if (Isselectcircle)
	{
		m_bLBtnDown = true;
		m_startPnt = point;
		m_circleMouse = s_Circle.elements[list];
		s_Circle.elements[list].color = RGB(255, 255, 255);
	}
}

void CMagicGis_Area::DeleteArea(CPoint &point, CDC *pDC){
	SelectArea(point, pDC);
	if (Isselectcircle)
	{
		if (MessageBox(NULL, _T("ȷ��ɾ��������"), _T("ɾ����"), MB_OKCANCEL | MB_ICONWARNING) == IDOK){
			s_Circle.elements[list].color = RGB(255, 255, 255);
			Draw(s_Circle.elements[list], pDC);
			/*Operation.deleteCircle(s_Circle.elements[list]);*/
			s_Circle.delete_elements(list);
			Isselectcircle = false;
		}
	}
}

void CMagicGis_Area::SquareDeleteArea(CDC *pDC)
{
	bool t;
	for (int i = 0; i<s_Circle.getSize(); i++)
	{
		t = true;
		for (int j = 0; j<s_Circle.elements[i].getSize(); j++)
		{
			if (OnMouseDelete(s_Circle.elements[i].data[j].x, s_Circle.elements[i].data[j].y, m_startp.x, m_startp.y, m_lastPnt.x, m_lastPnt.y))
			{
				t = false;
				break;
			}
		}
		if (t)
		{
			s_Circle.elements[i].color = RGB(255, 255, 255);
			Draw(s_Circle.elements[i], pDC);
			/*Operation.deleteCircle(s_Circle.elements[i]);*/
			s_Circle.delete_elements(i);
			i--;
		}
	}
}


void CMagicGis_Area::DrawBuffer(CDC * pDC, SeqStack<GeoCircle> & s_circle, int radium, CMagicGis_UpdateDoc * pDoc)
{
	CPen pen(PS_SOLID, 1, RGB(0, 255, 0));
	CPen *pOldPen = pDC->SelectObject(&pen);
	CBrush brush(RGB(0, 255, 0));
	CBrush *pOldBrush = pDC->SelectObject(&brush);
	pDC->SetROP2(R2_COPYPEN);

	//if (AreaType == 0)
	//{
	//	AfxMessageBox(_T("Type����δ��ȷ���룡"), MB_ICONEXCLAMATION);
	//	pDC->SelectObject(pOldPen);
	//	pDC->SelectObject(pOldBrush);
	//	return;
	//}
	for (int i = 0; i < s_circle.getSize(); i++)
	{
	if (s_circle.elements[i].type == 0)//Բ
	{
		/*for (int i = 0; i < numOfObject; i++)*/
		{
			CBrush brush(RGB(0, 255, 0));
			CBrush *pOldBrush = pDC->SelectObject(&brush);
			double r = sqrt(double((s_circle.elements[i].data[1].y - s_circle.elements[i].data[0].y)*(s_circle.elements[i].data[1].y - s_circle.elements[i].data[0].y)) + double((s_circle.elements[i].data[1].x - s_circle.elements[i].data[0].x)*(s_circle.elements[i].data[1].x - s_circle.elements[i].data[0].x)));
			pDC->Ellipse(s_circle.elements[i].data[0].x - r - radium, s_circle.elements[i].data[0].y + r + radium, s_circle.elements[i].data[0].x + r + radium, s_circle.elements[i].data[0].y - r - radium);
			brush.DeleteObject();
			brush.CreateSolidBrush(RGB(255, 255, 255));
			pOldBrush = pDC->SelectObject(&brush);
			pDC->Ellipse(s_circle.elements[i].data[0].x - r + radium, s_circle.elements[i].data[0].y + r - radium, s_circle.elements[i].data[0].x + r - radium, s_circle.elements[i].data[0].y - r + radium);
			pDC->SelectObject(pOldBrush);
		}
		pDC->SelectObject(pOldPen);
		pDC->SelectObject(pOldBrush);
	}
	else if (s_circle.elements[i].type == 1)//����
	{
		/*for (int j = 0; j < numOfObject; j++)*/
		{
			CPoint *newpoint = new CPoint[5];
			newpoint[0] = s_circle.elements[i].data[0]; newpoint[2] = s_circle.elements[i].data[1];
			newpoint[1].x = newpoint[2].x; newpoint[1].y = newpoint[0].y;
			newpoint[3].x = newpoint[0].x; newpoint[3].y = newpoint[2].y;
			newpoint[4] = newpoint[0];
			for (int i = 0; i < 4; i++)
			{
				CPoint* point = pDoc->CreateBufferEdge(newpoint[i], newpoint[i + 1], radium);
				pDoc->PointNum = 5;
				for (int i = 0; i < pDoc->PointNum - 1; i++)
				{
					pDC->MoveTo(point[i]); pDC->LineTo(point[i + 1]);
				}
				pDC->Polygon(point, pDoc->PointNum - 1);//���ö����ɨ������亯��
				pDC->Ellipse(newpoint[i].x - radium, newpoint[i].y + radium, newpoint[i].x + radium, newpoint[i].y - radium);
				pDC->Ellipse(newpoint[i + 1].x - radium, newpoint[i + 1].y + radium, newpoint[i + 1].x + radium, newpoint[i + 1].y - radium);
				pDoc->PointNum = 0;
				if (point != NULL)
					delete[] point;
			}
			delete[] newpoint;
		}
		pDC->SelectObject(pOldPen);
		pDC->SelectObject(pOldBrush);

		/*for (int j = 0; j < numOfObject; j++)*/
		{
			CPoint *newpoint = new CPoint[5];
			newpoint[0] = s_circle.elements[i].data[0]; newpoint[2] = s_circle.elements[i].data[1];
			newpoint[1].x = newpoint[2].x; newpoint[1].y = newpoint[0].y;
			newpoint[3].x = newpoint[0].x; newpoint[3].y = newpoint[2].y;
			newpoint[4] = newpoint[0];
			for (int i = 0; i < 4; i++)
			{
				pDC->MoveTo(newpoint[i]); pDC->LineTo(newpoint[i + 1]);
			}
			delete[] newpoint;
		}
	}
	else if (s_circle.elements[i].type == 2)//�����
	{
		/*for (int i = 0; i < s_circle.elements[i].; i++)*/
		{
			int n = s_circle.elements[i].getSize();
			CPoint *newPoint = new CPoint[n + 1];
			for (int j = 0; j < n; j++)
			{
				newPoint[j] = s_circle.elements[i].data[j];
			}
			newPoint[n] = s_circle.elements[i].data[0];
			for (int i = 0; i < n; i++)
			{
				pDC->MoveTo(newPoint[i]); pDC->LineTo(newPoint[i + 1]);
			}

			for (int i = 0; i < n; i++)
			{
				CPoint* point = pDoc->CreateBufferEdge(newPoint[i], newPoint[i + 1], radium);
				pDoc->PointNum = 5;
				for (int i = 0; i < pDoc->PointNum - 1; i++)
				{
					pDC->MoveTo(point[i]); pDC->LineTo(point[i + 1]);
				}
				pDC->Polygon(point, pDoc->PointNum - 1);//���ö����ɨ������亯��
				pDC->Ellipse(newPoint[i].x - radium, newPoint[i].y + radium, newPoint[i].x + radium, newPoint[i].y - radium);
				pDC->Ellipse(newPoint[i + 1].x - radium, newPoint[i + 1].y + radium, newPoint[i + 1].x + radium, newPoint[i + 1].y - radium);
				pDoc->PointNum = 0;
				if (point != NULL)
					delete[] point;
			}
			delete[] newPoint;
		}

		pDC->SelectObject(pOldPen);
		pDC->SelectObject(pOldBrush);
	}
		for (int i = 0; i <s_circle.getSize(); i++)
		{
			int num = s_circle.elements[i].getSize();
			CPoint *newPoint = new CPoint[num + 1];
			for (int j = 0; j < num; j++)
			{
				newPoint[j] = s_circle.elements[i].data[j];
			}
			newPoint[num] = s_circle.elements[i].data[0];
			for (int i = 0; i < num; i++)
			{
				pDC->MoveTo(newPoint[i]); pDC->LineTo(newPoint[i + 1]);
			}
			delete[] newPoint;
		}
	}
}
