#pragma once
#include "BaseTool.h"
class CMagicGis_Note :public CBaseTool
{
public:
	CMagicGis_Note(void);
	CMagicGis_Note(CView* ptView);
	virtual ~CMagicGis_Note(void);
public:
	void Draw(GeoNote &note, CDC *pDC);
	void SelectNote(GeoNote &note, CDC *pDC);
	void ModifyNote(GeoNote &note, CDC *pDC);
	void MoveNote(GeoNote &note, CDC *pDC);
	void DeleteNote(GeoNote &note, CDC *pDC);
	int LButtonDown(CDC *pDC, UINT nFlags, CPoint point);
	int LButtonUp(CDC *pDC, UINT nFlags, CPoint point);
	int MouseMove(CDC *pDC, UINT nFlags, CPoint point);
	int RButtonUp(CDC *pDC, UINT nFlags, CPoint point);
private:
	GeoNote note;
};