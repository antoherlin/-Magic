// ImportLayer.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MagicGis_Update.h"
#include "ImportLayer.h"
#include "afxdialogex.h"


// ImportLayer �Ի���

IMPLEMENT_DYNAMIC(ImportLayer, CDialogEx)

ImportLayer::ImportLayer(CWnd* pParent /*=NULL*/)
	: CDialogEx(ImportLayer::IDD, pParent)
{

}

ImportLayer::~ImportLayer()
{
}

void ImportLayer::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(ImportLayer, CDialogEx)
END_MESSAGE_MAP()


// ImportLayer ��Ϣ��������
