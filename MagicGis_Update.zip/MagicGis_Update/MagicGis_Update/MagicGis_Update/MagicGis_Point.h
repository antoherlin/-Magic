#pragma once
#include "BaseTool.h"

class CMagicGis_Point:public CBaseTool
{
public:
	CMagicGis_Point(void);
	CMagicGis_Point(CView* ptView);
	~CMagicGis_Point(void);
public:
	void Draw(GeoPoint &point, CDC *pDC);
	void SelectPoint(GeoPoint &point, CDC *pDC);
	void ModifyPoint(GeoPoint &point, CDC *pDC);
	void MovePoint(GeoPoint &point, CDC *pDC);
	void DeletePoint(GeoPoint &point, CDC *pDC);
	int LButtonDown(CDC *pDC, UINT nFlags, CPoint point);
	int LButtonUp(CDC *pDC, UINT nFlags, CPoint point);
	int MouseMove(CDC *pDC, UINT nFlags, CPoint point);
	int RButtonUp(CDC *pDC, UINT nFlags, CPoint point);
private:
	GeoPoint p;
public:
	void DrawBuffer(CDC * pDC, SeqStack<GeoPoint> &s_p, int radium);
};

