#pragma once


// SetBuffer �Ի���

class SetBuffer : public CDialogEx
{
	DECLARE_DYNAMIC(SetBuffer)

public:
	SetBuffer(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~SetBuffer();

// �Ի�������
	enum { IDD = IDD_BUFFER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRadioPoint();
	afx_msg void OnBnClickedRadioLine();
	afx_msg void OnBnClickedRadioArea();
	int action_type;
	int radius;
	afx_msg void OnBnClickedOk();
};
