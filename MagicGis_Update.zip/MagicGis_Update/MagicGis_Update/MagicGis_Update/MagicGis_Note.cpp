#include "stdafx.h"
#include "MagicGis_Note.h"

extern "C" BOOL WINAPI NoteDlg(COLORREF &N_color, int &N_mark, CString &N_note);

CMagicGis_Note::CMagicGis_Note(void)
{
	note.color = RGB(0, 0, 0);
	note.mnote = "";
	note.layer = -1;
}

CMagicGis_Note::CMagicGis_Note(CView* ptView)
{
	note.color = RGB(0, 0, 0);
	note.mnote = "";
	note.layer = -1;
	m_ptView = ptView;
}


CMagicGis_Note::~CMagicGis_Note(void)
{
}



int CMagicGis_Note::LButtonDown(CDC *pDC, UINT nFlags, CPoint point)
{
	switch(MenuID){
	case 51:
		int mark;
		NoteDlg(note.color, mark, note.mnote);
		note.mpoint = point;
		if (mark == 0)
		{
			Draw(note, pDC);
			note.layer = s_layer.elements[editlayer].id;
			//Operation.Connectiondb();
			//note.id=Operation.addNote(note);
			s_note.Push(note);
		}
		break;
	case 52:
		Draw(selectnote, pDC);
		note.mpoint = point;
		SelectNote(note, pDC);
		break;
	case 53:
		note.mpoint = point;
		ModifyNote(note, pDC);
		break;
	case 54:
		note.mpoint = point;
		MoveNote(note, pDC);
		break;
	case 55:
		note.mpoint = point;
		DeleteNote(note, pDC);
		break;
	}

	return (1);
}

int CMagicGis_Note::MouseMove(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID){
	case 54:
		if (m_bLBtnDown)
		{
			GeoNote temp_note = m_noteMouse;
			temp_note.color = RGB(255, 255, 255);
			Draw(temp_note, pDC);
			m_noteMouse.mpoint = point;
			Draw(m_noteMouse, pDC);
			selectnote = m_noteMouse;
		}
		break;
	}

	return (1);
}
int CMagicGis_Note::LButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{
	switch (MenuID)
	{
	case 54:
		if (m_bLBtnDown)
		{
			m_bLBtnDown = false;
			s_note.elements[list] = m_noteMouse;
			//Operation.Connectiondb();
			// Operation.modifyNote(s_note.elements[list]);
		}
		break;
	}
	return (1);
}

int CMagicGis_Note::RButtonUp(CDC *pDC, UINT nFlags, CPoint point)
{

	return (1);
}


void CMagicGis_Note::Draw(GeoNote &note, CDC *pDC)
{
	pDC->SetTextColor(note.color);
	pDC->TextOut(note.mpoint.x, note.mpoint.y, note.mnote);
}

void CMagicGis_Note::SelectNote(GeoNote &note, CDC *pDC)
{
	Isselectnote = false;
	for (int i = 0; i<s_note.getSize(); i++)
	{
		CSize size = pDC->GetTextExtent(s_note.elements[i].mnote);
		rect_note.SetRect((int)s_note.elements[i].mpoint.x, (int)s_note.elements[i].mpoint.y, (int)s_note.elements[i].mpoint.x + size.cx, (int)s_note.elements[i].mpoint.y + size.cy);
		if (rect_note.PtInRect(note.mpoint))
		{
			list = i;
			selectnote = s_note.elements[i];
			Isselectnote = true;
			break;
		}
	}
}

void CMagicGis_Note::ModifyNote(GeoNote &note, CDC *pDC)
{
	SelectNote(note, pDC);
	if (Isselectnote){
		int mark;
		COLORREF c;
		CString t_note;
		NoteDlg(c, mark, t_note);
		if (mark==0){
			s_note.elements[list].color = RGB(255, 255, 255);
			Draw(s_note.elements[list], pDC);
			s_note.elements[list].mnote = t_note;
			s_note.elements[list].color = c;
			//Operation.Connectiondb();
			//Operation.modifyNote(s_note.elements[list]);
			Draw(s_note.elements[list], pDC);
			selectnote = s_note.elements[list];
		}
	}
}

void CMagicGis_Note::MoveNote(GeoNote &note, CDC *pDC)
{
	SelectNote(note, pDC);
	if (Isselectnote)
	{
		m_bLBtnDown = true;
		m_noteMouse = s_note.elements[list];
		s_note.elements[list].color = RGB(255, 255, 255);
	}
}

void CMagicGis_Note::DeleteNote(GeoNote &note, CDC *pDC){
	SelectNote(note, pDC);
	if (Isselectnote)
	{
		if (MessageBox(NULL, _T("ȷ��ɾ���õ㣿"), _T("ɾ����"), MB_OKCANCEL | MB_ICONWARNING) == IDOK){
			s_note.elements[list].color = RGB(255, 255, 255);
			Draw(s_note.elements[list], pDC);
			// Operation.Connectiondb();
			//Operation.deleteNote(s_note.elements[list]);
			s_note.delete_elements(list);
			Isselectnote = false;
		}
	}
}