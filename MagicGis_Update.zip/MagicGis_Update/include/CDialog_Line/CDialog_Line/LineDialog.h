#pragma once
#include "Resource.h"
#include "afxwin.h"

// CLineDialog �Ի���

class CLineDialog : public CDialog
{
	DECLARE_DYNAMIC(CLineDialog)

public:
	CLineDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLineDialog();

// �Ի�������
	enum { IDD = IDD_Tool_Line };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	/*int m_Line_Width;*/
	CComboBox m_Line_Type;
	int m_Line_Color_r;
	int m_Line_Color_g;
	int m_Line_Color_b;
	afx_msg void OnBnClickedLineColor();
	afx_msg void OnBnClickedLineok();
	afx_msg void OnBnClickedLinecancel();
	int m_Line_Width;
};

extern "C" __declspec(dllexport) BOOL WINAPI LineDlg(int &L_mark, int &L_type, int &L_width, COLORREF &L_color);