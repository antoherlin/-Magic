// LineDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CDialog_Line.h"
#include "LineDialog.h"
#include "afxdialogex.h"

CLineDialog dlg;
int Line_type = 0;
int Line_mark = 0;
int Line_width = 1;
COLORREF Line_color = RGB(0, 0, 0);


// CLineDialog �Ի���

IMPLEMENT_DYNAMIC(CLineDialog, CDialog)

CLineDialog::CLineDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CLineDialog::IDD, pParent)
	, m_Line_Color_r(0)
	, m_Line_Color_g(0)
	, m_Line_Color_b(0)
	, m_Line_Width(0)
{

}

CLineDialog::~CLineDialog()
{
}

void CLineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_Line_Width, m_Line_Width);
	DDX_Control(pDX, IDC_Line_Type, m_Line_Type);
	DDX_Text(pDX, IDC_Line_Color_r, m_Line_Color_r);
	DDX_Text(pDX, IDC_Line_Color_g, m_Line_Color_g);
	DDX_Text(pDX, IDC_Line_Color_b, m_Line_Color_b);
	DDX_Text(pDX, IDC_Line_Width, m_Line_Width);
}


BEGIN_MESSAGE_MAP(CLineDialog, CDialog)
	ON_BN_CLICKED(IDC_Line_Color, &CLineDialog::OnBnClickedLineColor)
	ON_BN_CLICKED(IDC_LineOK, &CLineDialog::OnBnClickedLineok)
	ON_BN_CLICKED(IDC_LineCancel, &CLineDialog::OnBnClickedLinecancel)
END_MESSAGE_MAP()


// CLineDialog ��Ϣ��������


void CLineDialog::OnBnClickedLineColor()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);
	CColorDialog dlg_C;
	COLORREF color;
	CString text;
	if (dlg_C.DoModal() == IDOK)
	{
		color = dlg_C.GetColor();
		m_Line_Color_r = GetRValue(color);
		m_Line_Color_g = GetGValue(color);
		m_Line_Color_b = GetBValue(color);
		UpdateData(FALSE);
	}
	
}


void CLineDialog::OnBnClickedLineok()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);
	CString  strTemp;
	dlg.m_Line_Type.GetWindowText(strTemp);
	if (strTemp == "ʵ��")
		Line_type = PS_SOLID;
	else if (strTemp == "����")
		Line_type = PS_DASH;
	else if (strTemp == "����")
		Line_type = PS_DOT;
	else if (strTemp == "�㻮��")
		Line_type = PS_DASHDOT;
	else if (strTemp == "˫�㻮��")
		Line_type = PS_DASHDOTDOT;
	if (dlg.m_Line_Color_r != 0 || dlg.m_Line_Color_g != 0 || dlg.m_Line_Color_b != 0)
		Line_color = RGB(dlg.m_Line_Color_r, dlg.m_Line_Color_g, dlg.m_Line_Color_b);
	CString text;
	Line_width = m_Line_Width;
	UpdateData(FALSE);
	CDialog::OnOK();
}


void CLineDialog::OnBnClickedLinecancel()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	Line_mark = 1;
	CDialog::OnCancel();
}

extern "C" __declspec(dllexport) BOOL WINAPI LineDlg(int &L_mark, int &L_type, int &L_width, COLORREF &L_color)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if (dlg.DoModal() == IDOK)
	{
		L_type = Line_type;
		L_color = Line_color;
		L_mark = Line_mark;
		L_width = Line_width;
		return(1);
	}
	else
	{
		return(0);
	}
}
