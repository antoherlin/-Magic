// NoteDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CDialog_Note.h"
#include "NoteDialog.h"
#include "afxdialogex.h"


// CNoteDialog �Ի���

IMPLEMENT_DYNAMIC(CNoteDialog, CDialogEx)

CNoteDialog::CNoteDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CNoteDialog::IDD, pParent)
	, N_r(0)
	, N_g(0)
	, N_b(0)
	, mark(0)
{

}

CNoteDialog::~CNoteDialog()
{
}

void CNoteDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_edit);
	DDX_Text(pDX, IDC_EDIT2, N_r);
	DDX_Text(pDX, IDC_EDIT3, N_g);
	DDX_Text(pDX, IDC_EDIT6, N_b);
}


BEGIN_MESSAGE_MAP(CNoteDialog, CDialogEx)
	ON_BN_CLICKED(IDC_ChooseColor, &CNoteDialog::OnBnClickedChoosecolor)
	ON_BN_CLICKED(IDOK, &CNoteDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CNoteDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CNoteDialog ��Ϣ��������


void CNoteDialog::OnBnClickedChoosecolor()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	CColorDialog dlg1;
	COLORREF color;
	CString text;
	m_edit.GetWindowText(text);
	m_note = text;
	if (dlg1.DoModal() == IDOK)
	{

		color = dlg1.GetColor();
		N_r = GetRValue(color);
		N_g = GetGValue(color);
		N_b = GetBValue(color);
		UpdateData(false);
	}
}


void CNoteDialog::OnBnClickedOk()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	CDialogEx::OnOK();
}


void CNoteDialog::OnBnClickedCancel()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	mark == 1;
	CDialogEx::OnCancel();
}

extern "C" __declspec(dllexport) BOOL WINAPI NoteDlg(COLORREF &color, int &mark, CString &note)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	CNoteDialog dlg;
	if (dlg.DoModal() == IDOK)
	{
		color = RGB(dlg.N_r, dlg.N_g, dlg.N_b);
		mark =dlg.mark;
		note = dlg.m_note;
		return(1);
	}
	else
	{
		return(0);
	}
}

