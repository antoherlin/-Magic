#pragma once
#include "afxwin.h"


// CNoteDialog �Ի���

class CNoteDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CNoteDialog)

public:
	CNoteDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CNoteDialog();

// �Ի�������
	enum { IDD = IDD_DialogNote };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_edit;
	int N_r;
	int N_g;
	int N_b;
	afx_msg void OnBnClickedChoosecolor();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	CString m_note;
	int mark;
};
