#pragma once
#include "afxwin.h"


// CAreaDialog �Ի���

class CAreaDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CAreaDialog)

public:
	CAreaDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CAreaDialog();

// �Ի�������
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedColor();
	int A_r;
	int A_g;
	int A_b;
	int mtype;
	afx_msg void OnBnClickedCancel();
	CComboBox m_type;
	afx_msg void OnBnClickedOk();
};
