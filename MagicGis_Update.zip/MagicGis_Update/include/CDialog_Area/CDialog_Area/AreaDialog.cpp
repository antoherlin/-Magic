// AreaDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CDialog_Area.h"
#include "AreaDialog.h"
#include "afxdialogex.h"

// CAreaDialog �Ի���

int A_mark = 0;

IMPLEMENT_DYNAMIC(CAreaDialog, CDialogEx)

CAreaDialog::CAreaDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CAreaDialog::IDD, pParent)
	, A_r(0)
	, A_g(0)
	, A_b(0)
	, mtype(0)
{

}

CAreaDialog::~CAreaDialog()
{
}

void CAreaDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_R, A_r);
	DDX_Text(pDX, IDC_G, A_g);
	DDX_Text(pDX, IDC_B, A_b);
	DDX_Control(pDX, IDC_COMBO1, m_type);
}


BEGIN_MESSAGE_MAP(CAreaDialog, CDialogEx)
	ON_BN_CLICKED(IDC_COLOR, &CAreaDialog::OnBnClickedColor)
	ON_BN_CLICKED(IDCANCEL, &CAreaDialog::OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, &CAreaDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CAreaDialog ��Ϣ��������


void CAreaDialog::OnBnClickedColor()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	CColorDialog dlg;
	COLORREF color;
	if (dlg.DoModal())
	{
		color = dlg.GetColor();
		A_r = GetRValue(color);
		A_g = GetGValue(color);
		A_b = GetBValue(color);
		UpdateData(false);
	}
}

extern "C" __declspec(dllexport) BOOL WINAPI AreaDlg(COLORREF &color, int &mark,int &type)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	CAreaDialog dlg;
	if (dlg.DoModal() == IDOK)
	{
		color = RGB(dlg.A_r, dlg.A_g, dlg.A_b);
		mark = A_mark;
		type = dlg.mtype;
		return(1);
	}
	else
	{
		return(0);
	}
}


void CAreaDialog::OnBnClickedCancel()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	A_mark = 1;
	CDialogEx::OnCancel();
}


void CAreaDialog::OnBnClickedOk()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	CString  strTemp;
	UpdateData(true);
	m_type.GetWindowText(strTemp);
	if (strTemp == "Բ")
		mtype = 0;
	else if (strTemp == "����")
		mtype = 1;
	else if (strTemp =="�Զ�������")
		mtype = 2;
	UpdateData(false);
	CDialogEx::OnOK();
}