#pragma once
#include "Resource.h"


// CPointDialog �Ի���

class CPointDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CPointDialog)

public:
	CPointDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPointDialog();

// �Ի�������
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRadioSqu();
	afx_msg void OnBnClickedRadioCrt();
	afx_msg void OnBnClickedRadioCrl();
	int P_type;
	int P_R;
	int P_G;
	int P_B;
	afx_msg void OnBnClickedChooseColor();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
